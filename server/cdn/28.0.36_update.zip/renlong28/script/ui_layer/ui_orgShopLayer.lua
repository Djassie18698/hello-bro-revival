----------------------------------------------------------------------
--  Copyright (c) 2014-2016, XCKOO. All Rights Reserved.
--  Author :Tango
--  Time   :2014/11/24 19:53:55
--  Remark :组织商城
----------------------------------------------------------------------
module("ui_orgShopLayer", package.seeall)
baseClass(layer_base_t, ui_orgShopLayer)

function init(self)
	self.playerMgr_ = CPlayerDataMgr:instance()
	self.playerData_ = self.playerMgr_:GetPlayerInfoData()

	self.contentSize_ = GetMainMenu():GetSubContentNode():getContentSize()
	local ccbiAttrTable = { name = "sub_ui/OrgShopView.ccbi", size = self.contentSize_ }
	layer_base_t.init(self, true, ccbiAttrTable)

	-- pre page
	self.back_page = E_DEFAULTMENU

	-- data
	self.tableData = { }
	self.cellNodes = { }

	-- 时间增量
	self.deltatime = 0
	self.myscore = 0
	-- init
	self:init_ui()
	self:init_binding_event()
end

function init_ui(self)
	if self.proxy_ ~= nil then
		-- node
		self.node_content = tolua.cast(self.proxy_:getNode("node_content"), "CCNode")
		self.node_cell = tolua.cast(self.proxy_:getNode("node_cell"), "CCNode")
		-- btn
		self.btn_back = tolua.cast(self.proxy_:getNode("btn_back"), "CCControlButton")

		-- label
		self.labelMyScore = tolua.cast(self.proxy_:getNode("label_contrib"), "CCLabelTTF")
		self.labelTime = tolua.cast(self.proxy_:getNode("label_countdown"), "CCLabelTTF")

		self:initTopBar()
		self:init_ext_topBar()

		-- base request
		self:requestBaseLayerInfo()
		--self:createTestData()
	end
end

function initTopBar(self)
	if self.proxy_ ~= nil then
		self.sprite_playermedal = tolua.cast(self.proxy_:getNode("sprite_playermedal"), "CCSprite")
		self.label_level = tolua.cast(self.proxy_:getNode("label_level"), "CCLabelBMFont")
		self.label_curexp = tolua.cast(self.proxy_:getNode("label_curexp"), "CCLabelBMFont")
		self.label_name = tolua.cast(self.proxy_:getNode("label_name"), "CCLabelTTF")
		self.sprite_vipinfo = tolua.cast(self.proxy_:getNode("sprite_vipinfo"), "CCSprite")
		self.label_bodyval = tolua.cast(self.proxy_:getNode("label_bodyval"), "CCLabelBMFont")
		self.label_attackval = tolua.cast(self.proxy_:getNode("label_attackval"), "CCLabelBMFont")
		self.label_goldval = tolua.cast(self.proxy_:getNode("label_goldval"), "CCLabelBMFont")
		self.label_silverval = tolua.cast(self.proxy_:getNode("label_silverval"), "CCLabelBMFont")
		self.ctrl_btnplayermsg = tolua.cast(self.proxy_:getNode("ctrl_btnplayermsg"), "CCControlButton")
		self.sprite_levelstate = tolua.cast(self.proxy_:getNode("sprite_levelstate"), "CCSprite")
		self.sprite_bodyratio = tolua.cast(self.proxy_:getNode("sprite_bodyratio"), "CCSprite")
		self.sprite_attackratio = tolua.cast(self.proxy_:getNode("sprite_attackratio"), "CCSprite")
	end
end

-- 人物信息
function init_ext_topBar(self)
	if self.proxy_ ~= nil then
		local meritIcon = self.playerMgr_:GetMeritIcon()
		if meritIcon ~= nil then
			local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(meritIcon)
			if pFrame ~= nil then
				self.sprite_playermedal:setDisplayFrame(pFrame)
			end
		end
		-- exp
		self.label_name:setString(self.playerData_.m_name)
		local nextExp = self.playerMgr_:GetNextLevelExp()
		local expStr = tostring(self.playerData_.m_exp) .. "/" .. tostring(nextExp)
		self.label_curexp:setString(expStr)
		self.sprite_levelstate:setScaleX(self.playerData_.m_exp / nextExp)

		-- vipinfo
		local viplevel = self.playerData_.m_viplevel
		local vipframes = {
			[0] = "vip_015",
			[1] = "vip_003",
			[2] = "vip_004",
			[3] = "vip_005",
			[4] = "vip_006",
			[5] = "vip_007",
			[6] = "vip_008",
			[7] = "vip_009",
			[8] = "vip_010",
			[9] = "vip_011",
			[10] = "vip_012",
			[11] = "vip_013",
			[12] = "vip_014",
			[13] = "vip_s_13",
			[14] = "vip_s_14",
			[15] = "vip_s_15",
			[16] = "vip_s_16",
			[17] = "vip_s_17",
			[18] = "vip_s_18"
		}
		if self.sprite_vipinfo ~= nil then
			local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(vipframes[viplevel])
			self.sprite_vipinfo:setDisplayFrame(pFrame)
		end

		-- bodyval
		local maxbodyval = self.playerMgr_:GetMaxBodyValue()
		local bodyValStr = tostring(self.playerData_.m_bodyvalue) .. "/" .. tostring(maxbodyval)
		self.label_bodyval:setString(bodyValStr)
		local scaleVal = self.playerData_.m_bodyvalue / maxbodyval
		if scaleVal > 1 then
			scaleVal = 1
		end
		self.sprite_bodyratio:setScaleX(scaleVal)

		-- attack
		local maxattack = self.playerMgr_:GetMaxAttackCount()
		local attackValStr = tostring(self.playerData_.m_fightcount) .. "/" .. tostring(maxattack)
		self.label_attackval:setString(attackValStr)
		self.sprite_attackratio:setScaleX(self.playerData_.m_fightcount / maxattack)

		-- gold & silver
		self.label_goldval:setString(tostring(self.playerData_.m_gold))
		self.label_silverval:setString(tostring(self.playerData_.m_silver))
		self.label_level:setString(tostring(self.playerData_.m_level))
	end
end

function requestBaseLayerInfo(self)
	-- 获取基本信息
	local urlpath = GetUrlNormalHeader(self.playerData_.m_uid, 1, "rl_r_group_store")
	urlpath = AddData(urlpath, "GroupId", global.myOrgId)
	cclog("rl_r_group_store & cmd = 1---%s", urlpath)
	GetMainMenu():ShowLoadingDlg()
	CCHttpRequest:open(urlpath, kHttpPost, "query=param1&other=params"):sendWithHandler(
	function(res, hnd)
		GetMainMenu():CloseLoadding()
		local resData = res:getResponseData()
		local code = res:getResponseCode()
		local xfile = xml.parse(resData)
		local item = xfile:find("RENLONG")
		if item == nil then
			return nil
		end
		-- cclog("rl_r_group_store ret = %s", resData)
		local retcode = item.code
		if retcode == "0" then
			local store = item:find("store_info")
			self.m_resttime = tonumber(store:find("remain_time")[1])
			self.myscore = store:find("user_score")[1]

			local itemlist = item:find("item_list")
			local line = {}
			for i,v in ipairs(itemlist) do
				table.insert(line,v)
				if #line == 3 then
					table.insert(self.tableData,line)
					line = {}
				end
			end
			if #line > 0 then
				table.insert(self.tableData,line)
			end
			-- ext init ui
			self:init_ext_ui()
		else
			GetMainMenu():ShowErrorTip(tonumber(retcode), -1)
		end
	end )
end

function init_ext_ui(self)
	self:createTableView()

	local function updateLeftTimeLabel(fDeltaTime)
		self.deltatime = self.deltatime + fDeltaTime
		if self.deltatime >= 1 then
			local intPart, floatPart = math.modf(self.deltatime)
			self.m_resttime = self.m_resttime - intPart
			if self.m_resttime > 0 then
				local timeStr = tools.convertTimeElectronicWatch(self.m_resttime, 3)
				self.labelTime:setString(timeStr)
				self.deltatime = floatPart
			else
				self.m_state = 1
				self.labelTime:unscheduleUpdate()
			end
		end
	end

	self.labelMyScore:setString(self.myscore)
	-- 实时更新活动时间
	if self.m_resttime > 0 then
		self.labelTime:scheduleUpdateWithPriorityLua(updateLeftTimeLabel, 0)
		self.labelTime:setString(tools.convertTimeElectronicWatch(self.m_resttime, 3))
	else
		self.labelTime:setString("Ended") -- was 结束 (revival: English)
	end
end

function createTableView(self)
	if self._tableView == nil then
		local cellContentSize = self.node_cell:getContentSize()
		self._cell_size = CCSizeMake(cellContentSize.width, cellContentSize.height)

		self._content_size = self.node_content:getContentSize()
		self:initTableHandle()
		self._tableView = LuaTableView:createWithHandler(self._tableViewHandler, CCSizeMake(self._content_size.width, self._content_size.height))
		self._tableView:setDirection(kCCScrollViewDirectionVertical)
		self._tableView:setVerticalFillOrder(kCCTableViewFillTopDown)
		self._tableView:setTouchPriority(kCCMenuHandlerPriority - 1)

		self.node_content:addChild(self._tableView)
	else
		self._tableView:reloadData()
	end
end

function requestBuy(self,index)
	local urlpath = GetUrlNormalHeader(self.playerData_.m_uid, 2, "rl_r_group_store")
	urlpath = AddData(urlpath, "GroupId", global.myOrgId)
	urlpath = AddData(urlpath, "ItemIndex", index)
	-- cclog("rl_r_group_store & cmd = 2---%s", urlpath)
	GetMainMenu():ShowLoadingDlg()
	CCHttpRequest:open(urlpath, kHttpPost, "query=param1&other=params"):sendWithHandler(
	function(res, hnd)
		GetMainMenu():CloseLoadding()
		local resData = res:getResponseData()
		local code = res:getResponseCode()
		local xfile = xml.parse(resData)
		local item = xfile:find("RENLONG")
		if item == nil then
			return nil
		end
		-- cclog("rl_r_group_store ret = %s", resData)
		local retcode = item.code
		if retcode == "0" then
			local awardXML = item:find("award")
			--显示掉落动画	
			ShowAward(awardXML)	

			local store = item:find("store_info")
			self.m_resttime = tonumber(store:find("remain_time")[1])
			self.myscore = store:find("user_score")[1]

			self.tableData = {}
			local itemlist = item:find("item_list")
			local line = {}
			for i,v in ipairs(itemlist) do
				table.insert(line,v)
				if #line == 3 then
					table.insert(self.tableData,line)
					line = {}
				end
			end
			if #line > 0 then
				table.insert(self.tableData,line)
			end
			-- ext init ui
			self:init_ext_ui()
		else
			GetMainMenu():ShowErrorTip(tonumber(retcode), -1)
		end
	end )
end
function onClickedBuy( self, line, i )
	CSoundMgr:instance():PlayEffect(SOUND_BUTTON)
	if line < 0 or line > #self.tableData then
		--GetMainMenu():ShowTextTip(localizable.ui_hall_net_error, -1)
		return nil
	end
	if i < 0 or i > #self.tableData[line] then
		return nil
	end
	cclog('点击购买：%d,%d',line,i)

	--todo: 检查条件
	local item = self.tableData[line][i]
	local needCash = tonumber(item.cost_cash)
	if needCash > self.playerData_.m_gold then
		--提示购买元宝
		GetMainMenu():ShowTextTip(localizable.ui_monopoly_gold_not_enough,-1)
		--通用付费引导
		local prePayLayer = createObj(ui_commonPrePay)
		GetMainMenu():GetModelLayer():AddDialog(prePayLayer.node_, 3)
		return nil
	end

	local index = tonumber(item.item_index)
	self:requestBuy(index)
end

function onClickedItem( self, line, i )
	CSoundMgr:instance():PlayEffect(SOUND_BUTTON)
	if line < 0 or line > #self.tableData then
		--GetMainMenu():ShowTextTip(localizable.ui_hall_net_error, -1)
		return nil
	end
	if i < 0 or i > #self.tableData[line] then
		return nil
	end
	cclog('点击图标：%d,%d',line,i)

	local _id_icon = tonumber(self.tableData[line][i].store_drop)
	if nil ~= _id_icon then
		CGameObjElement:ShowDropByID(_id_icon)
	end
	
end

function initTableHandle(self)

	self._tableViewHandler = LuaEventHandler:create( function(fn, table, a1, a2, x, y)
		local r
		if fn == "cellSize" then
			r = self._cell_size;
		elseif fn == "cellAtIndex" then
			local nodeLayer = createObj(ui_orgShopCell, self._cell_size, self.tableData[a1 + 1])
			-- tableView cell container
			self.cellNodes[a1 + 1] = nodeLayer
			if not a2 then
				a2 = CCTableViewCell:create()
				a2:addChild(nodeLayer.node_)
			else
				a2:removeAllChildrenWithCleanup(true)
				a2:addChild(nodeLayer.node_)
			end
			r = a2
		elseif fn == "numberOfCells" then
			r = #self.tableData;
			-- Cell events:
		elseif fn == "cellTouched" then
			-- A cell was touched, a1 is cell that be touched. This is not necessary.
			local cell_index = a1:getIdx() + 1
			local cellData = self.tableData[cell_index]
			local cellNode = self.cellNodes[cell_index]
			for i = 1,3 do
				if cellNode.nodeGrid[i]:isVisible() then
					local pt = cellNode.nodeGrid[i]:convertToNodeSpace(self.m_touchPoint)
					if cellNode.btnBuy[i]:isEnabled() and cellNode.btnBuy[i]:boundingBox():containsPoint(pt) then
						self:onClickedBuy(cell_index,i)
						break
					elseif cellNode.sprItem[i]:boundingBox():containsPoint(pt) then
						self:onClickedItem(cell_index,i)
						break
					end
				end
			end
			self.m_touchPoint = nil  
		elseif fn == "cellTouchBegan" then
			-- A cell is touching, a1 is cell, a2 is CCTouch
			self.m_touchPoint = a2:getLocation()	
			--self.m_touchPoint = a1:convertToNodeSpace(self.m_touchPoint)
			r = true
		elseif fn == "cellTouchEnded" then
			-- A cell was touched, a1 is cell, a2 is CCTouch
			r = true
		elseif fn == "cellHighlight" then
			-- A cell is highlighting, coco2d-x 2.1.3 or above
		elseif fn == "cellUnhighlight" then
			-- A cell had been unhighlighted, coco2d-x 2.1.3 or above
		elseif fn == "cellWillRecycle" then
			-- A cell will be recycled, coco2d-x 2.1.3 or above
		end
		return r
	end )
end

function updateUI(self)
	-- update UI
end

function init_binding_event(self)
	if self.proxy_ ~= nil then
		local function onBtnBack(btn, event)
			--GetMainMenu():ChangeToSub(self.back_page)
			self.node_:removeFromParentAndCleanup(true)
			ShowOrgMapLayer()
		end

		self.btn_back:setTouchPriority(kCCMenuHandlerPriority - 1)
		self.btn_back:setTouchEnabled(true)
		self.proxy_:handleButtonEvent(self.btn_back, function(button, event)
			onBtnBack(button)
			return nil
		end , CCControlEventTouchDown)

		self.ctrl_btnplayermsg:setTouchPriority(kCCMenuHandlerPriority - 1)
		self.ctrl_btnplayermsg:setTouchEnabled(true)
		self.proxy_:handleButtonEvent(self.ctrl_btnplayermsg, function(button, event)
			GetMainMenu():OnShowUserInfo()
			return nil
		end, CCControlEventTouchDown)
	end
end

function createTestData(self)
	-- testdata
	for i = 1, 2 do
		local data = { 
		{store_drop = "115",store_icon='props_142',onoff='1', min_store_level='3', buyflag='0', cost_score='100', cost_cash='20'},
		{store_drop = "119",store_icon='props_143',onoff='1', min_store_level='3', buyflag='1', cost_score='100', cost_cash='0'},
		{store_drop = "129",store_icon='props_145',onoff='0', min_store_level='3', buyflag='0', cost_score='100', cost_cash='20'}
		}
		table.insert(self.tableData, data)
	end

	-- local data = { { } }
	-- table.insert(self.tableData, data)

	self.m_resttime = 1324554
	self.myscore = 9631

	self:init_ext_ui()
end

function onNodeCleanup(self)
	if self.proxy_ then
		self.proxy_:release()
	end

	layer_base_t.onNodeCleanup(self)
end
